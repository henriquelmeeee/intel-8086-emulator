#include "Base.h"

unsigned short ports[255]={};

namespace Device {

}
