#pragma once

#ifndef EXCEPTIONS
#define EXCEPTIONS

#define _DIVISION_BY_ZERO 0
#define _INVALID_OPCODE 6

#endif
