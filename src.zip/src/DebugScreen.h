#pragma once

#ifndef DEBUGS
#define DEBUGS

#include <SDL2/SDL.h>
#include <SDL2/SDL_ttf.h>
#include <iostream>
#include <stdlib.h>
#include <stdio.h>

void DebugScreenThread();

#endif
