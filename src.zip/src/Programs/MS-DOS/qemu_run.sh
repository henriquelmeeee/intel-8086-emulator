qemu-system-i386 -drive file=msdos.img,format=raw
