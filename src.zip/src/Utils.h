#pragma once

#ifndef UTILS_H
#define UTILS_H

//#define CONNECT_BY_GDB

#define VIDEO_MEMORY_BASE 0xB8000

extern unsigned long cursor_location;

#define RETURN return {}

/* GDB-related */
  #define PORT 1234
  
#endif
