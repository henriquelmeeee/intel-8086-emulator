sudo apt-get update
sudo apt-get install libboost-program-options-dev
sudo apt-get install libsdl2-image-dev

